# version.py
__version__ = "0.3.0"

""" version notes
0.2.0: added __del__ method to myRio class to close the connection
       to the myRIO (2024/03/05)
0.2.3: fixed the Default.lvbitx error: now the file is distributed 
       with the package. We use the relative folder of __file__ (2024/3/6)
0.3.0: Added examples. Fixed a bug in the digital write function. (2024/3/7)
"""

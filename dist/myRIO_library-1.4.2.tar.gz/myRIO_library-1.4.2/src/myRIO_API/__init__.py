# __init__.py
from .version import __version__
from .myRIO_API import *

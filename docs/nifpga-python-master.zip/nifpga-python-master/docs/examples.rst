.. _examples_page:

========
Examples
========
This Section will go different snippets of example code using the FPGA Interface python API to accomplish different tasks. Use the following links to navigate to the examples.

.. toctree::
   :maxdepth: 3
   :caption: Table of Contents:

   examples/basic_examples

.. _getting_started_page:
===============
Getting Started
===============

This document will show you how to get up and running with the NI FPGA Interface
Python API.

.. toctree::
   :maxdepth: 2
   :caption: User Documentation

   installation
   examples/basic_examples
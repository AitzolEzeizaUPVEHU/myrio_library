.. _api_registers_page:

=========
Registers
=========

.. autoclass:: nifpga.session._Register
    :members:
    :special-members: __len__
    :undoc-members:
    :show-inheritance:

.. _api_sessions_page:

========
Sessions
========

.. autoclass:: nifpga.session.Session
    :special-members: __init__
    :members:
    :undoc-members:
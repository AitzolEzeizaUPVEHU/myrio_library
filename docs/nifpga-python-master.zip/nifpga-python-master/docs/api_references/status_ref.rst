.. _api_status_page:

======
Status
======

.. autoclass:: nifpga.status.Status
   :special-members: __init__, __str__
   :members:
   :show-inheritance:

.. autoclass:: nifpga.status.WarningStatus
   :members:
   :show-inheritance:

.. autoclass:: nifpga.status.ErrorStatus
   :members:
   :show-inheritance:
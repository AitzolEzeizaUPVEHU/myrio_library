.. _api_array_registers_page:

===============
Array Registers
===============

.. autoclass:: nifpga.session._ArrayRegister
    :members:
    :special-members: __len__
    :undoc-members:
    :inherited-members:
    :show-inheritance:

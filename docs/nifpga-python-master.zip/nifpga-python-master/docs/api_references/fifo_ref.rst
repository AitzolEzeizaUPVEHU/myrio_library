.. _api_fifos_page:

=====
FIFOs
=====

.. autoclass:: nifpga.session._FIFO
    :members:
    :undoc-members:
    :show-inheritance:
